import socket
import json
import sys
import pyautogui
import subprocess
import base64
from PIL import Image
from io import BytesIO

def hex_to_file(hex_string, output_file_path):
    # Convert hex string to bytes
    byte_data = bytes.fromhex(hex_string)

    # Write the byte data to the output file
    with open(output_file_path, 'wb') as file:
        file.write(byte_data)

    print(f"File has been written to: {output_file_path}")

def save_screenshot(file_path):
    # Take a screenshot of the screen
    screenshot = pyautogui.screenshot()

    # Save the screenshot to the given file path
    screenshot.save(file_path)

    print(f"Screenshot saved to {file_path}")

def file_to_hex(file_path):
    # Read the file as bytes
    with open(file_path, 'rb') as file:
        byte_data = file.read()

    # Convert bytes to hex
    hex_string = byte_data.hex()

    return hex_string

def capture_screen():
    save_screenshot("screenshot_tmp_remote_host.png")
    return file_to_hex("screenshot_tmp_remote_host.png")

def handle_command(data, client_socket):
 action = data.get("action")
 try:
    if action == "python":
        if "--disable-python" in sys.argv:
            print("Not executing python due to --disable python flag. requested code:", data.get("script", "No Provided"))
            return
        try:
            exec(data.get("script", ""))
        except Exception as e:
            client_socket.sendall(json.dumps({"action": "err_response", "msg": str(e)}).encode('utf-8'))
    elif action == "keypress":
        if "--disable-keypress" in sys.argv:
            print("Not pressing key due to --disable-keypress flag. requested key:", data.get("key", "Not Provided"))
            return
        key = data.get("key")
        if key:
            pyautogui.press(key)
    elif action == "mousemove":
        if "--disable-mousemove" in sys.argv:
            print("Not moving mouse due to --disable-mousemove flag. requested position:", data.get("position", [0, 0]))
            return
        x, y = data.get("position", [0, 0])
        pyautogui.moveTo(x, y)
    elif action == "hotkey":
        pyautogui.hotkey(data.get["hotkey"])
    elif action == "subprocess":
        if "--disable-subprocess" in sys.argv:
            print("Not executing subprocess due to --disable-subprocess flag. requested command:", data.get("command", "No Provided"))
            return
        command = data.get("command")
        output = subprocess.run(command, capture_output=True, shell=True)
        outputjson = {"stdout": str(output.stdout), "stderr": str(output.stderr)}
        client_socket.sendall(json.dumps({"action": "subprocess", "output": outputjson}).encode('utf-8'))
    elif action == "get_screen":
        img_str = capture_screen()
        client_socket.sendall(json.dumps({"action": "screen_update", "image": img_str}).encode('utf-8'))
    elif action == "click":
        x, y = pyautogui.position()
        if data.get("type") == "left":
            pyautogui.click(x, y)
        if data.get("type") == "left":
            pyautogui.rightClick(x, y)
        if data.get("type") == "left":
            pyautogui.middleClick(x, y)
    elif action == "scroll_mouse":
        pyautogui.scroll(data.get("delta"))
    elif action == "upload_file":
        hex_to_file(data.get("file_hex"), data.get("path"))
    elif action == "download_file":
        file_hex = file_to_hex(data.get("remote_path"))
        client_socket.sendall(json.dumps({"action": "download_file", "file_hex": file_hex, "file_path": data.get("local_path")}).encode('utf-8'))
    elif action == "verifyconnection":
        # Respond with a verification response
        client_socket.sendall(json.dumps({"action": "verifyresponse"}).encode('utf-8'))
 except Exception as err:
    if "--end-on-error" in sys.argv:
            raise err
    try:
        client_socket.sendall(json.dumps({"action": "err_response", "msg": str(err)}).encode('utf-8'))
    except Exception as e:
        print("Failed to send error message back to controlling host. error message:", err)

def start_server(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((host, int(port)))
        server_socket.listen()
        print(f"Listening for commands on {host}:{port}...")
        
        while True:
            client_socket, addr = server_socket.accept()
            with client_socket:
                print(f"Connected by {addr}")
                data = client_socket.recv(1024)
                
                if not data:
                    break

                try:
                    command_data = json.loads(data.decode())
                    handle_command(command_data, client_socket)
                except json.JSONDecodeError:
                    print("Received invalid JSON")

if __name__ == "__main__":
    if False:
        print("Usage: python ControllableServer.py <host> <port>")
    else:
        host = sys.argv[1]
        port = sys.argv[2]
        start_server(host, port)

