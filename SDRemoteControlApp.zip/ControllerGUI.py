import socket
import json
import tkinter as tk
import pyautogui
import threading
import keyboard  # For capturing keyboard events
from PIL import Image, ImageTk
import base64
from io import BytesIO
import time
import easygui

def set_image_to_label(label: tk.Label, image_path: str):
    # Open the image using PIL
    img = Image.open(image_path)
    
    # Convert the image to a format Tkinter can use
    img_tk = ImageTk.PhotoImage(img)
    
    # Set the image to the label
    label.config(image=img_tk)
    
    # Keep a reference to the image to prevent it from being garbage collected
    label.image = img_tk

def hex_to_file(hex_string, output_file_path):
    # Convert hex string to bytes
    byte_data = bytes.fromhex(hex_string)

    # Write the byte data to the output file
    with open(output_file_path, 'wb') as file:
        file.write(byte_data)

    print(f"File has been written to: {output_file_path}")

def file_to_hex(file_path):
    # Read the file as bytes
    with open(file_path, 'rb') as file:
        byte_data = file.read()

    # Convert bytes to hex
    hex_string = byte_data.hex()

    return hex_string

class RemoteControllerApp:
    def __init__(self, master, host, port):
        self.master = master
        self.host = host
        self.port = port
        self.master.title("Remote Controller")
    
        self.track_mouse = False
        self.track_keys = False
        keyboard.on_press(self.on_key_press)

        # Set up GUI components
        self.subprocess_label = tk.Label(master, text="Run Subprocess Command:")
        self.subprocess_label.pack()
        self.subprocess_entry = tk.Entry(master, width=50)
        self.subprocess_entry.pack()
        self.subprocess_button = tk.Button(master, text="Send Subprocess", command=self.send_subprocess_command)
        self.subprocess_button.pack()
        self.subprocess_output = tk.Label(text="")

        self.python_label = tk.Label(master, text="Execute Python Code:")
        self.python_label.pack()
        self.python_entry = tk.Entry(master, width=50)
        self.python_entry.pack()
        self.python_button = tk.Button(master, text="Send Python Code", command=self.send_python_command)
        self.python_button.pack()

        # Toggle tracking buttons
        self.track_mouse_button = tk.Button(master, text="Track Mouse", command=self.toggle_mouse_tracking)
        self.track_mouse_status = tk.Label(text="False")
        self.track_mouse_button.pack()
        self.track_keys_button = tk.Button(master, text="Track Keyboard", command=self.toggle_key_tracking)
        self.track_keys_status = tk.Label(text="False")
        self.track_keys_button.pack()

        # Screen preview
        self.screen_preview_label = tk.Label(master, text="Remote Screen Preview")
        self.screen_preview_label.pack()

        self.screen_canvas = tk.Label(master)
        self.screen_canvas.pack()

        threading.Thread(target=self.mouse_tracking, daemon=True).start()
        self.update_screen()

        self.master.bind("<MouseWheel>", self.on_scroll)  # Mouse scroll
        self.master.bind("<Button-1>", self.on_left_click)  # Left mouse click
        self.master.bind("<Button-2>", self.on_middle_click)  # Middle mouse click
        self.master.bind("<Button-3>", self.on_right_click)  # Right mouse click

        self.download_label = tk.Label(master, text="Download File (source):")
        self.download_label.pack()
        self.download_entry = tk.Entry(master, width=50)
        self.download_entry.pack()
        self.download_button = tk.Button(master, text="Download File", command=self.download_file)
        self.download_button.pack()

        self.upload_label = tk.Label(master, text="Upload File (destination):")
        self.upload_label.pack()
        self.upload_entry = tk.Entry(master, width=50)
        self.upload_entry.pack()
        self.upload_button = tk.Button(master, text="Upload File", command=self.upload_file)
        self.upload_button.pack()

        # Run the GUI main loop
        self.master.after(100, self.check_events)

    def on_scroll(self, event):
        if self.track_mouse:
            self.send_data({"action": "scroll_mouse", "delta": event.delta})
    
    def on_left_click(self, event):
        if self.track_mouse:
            self.send_data({"action": "click", "type": "left"})
    
    def on_right_click(self, event):
        if self.track_mouse:
            self.send_data({"action": "click", "type": "right"})
    
    def on_middle_click(self, event):
        if self.track_mouse:
            self.send_data({"action": "click", "type": "middle"})

    def mouse_tracking(self):
        while True:
            if self.track_mouse:
                self.send_data({"action": "mousemove", "position": pyautogui.position()})
            time.sleep(1)

    def receive_data(self, response):
            if response:
                if "--debug" in sys.argv:
                    print("utf-8 response:", response)
                    print("text response:", response.decode("utf-8"))
                response_data = json.loads(response.decode("utf-8"))  # Decode the JSON response
                if response_data["action"] == "screen_update":
                    self.update_screen_preview(response_data["image"])
                if response_data["action"] == "err_response":
                    easygui.msgbox(title="Error Response", msg="Error Message: " + response_data.get("msg"))
                if response_data["action"] == "subprocess":
                    outputtext = response_data["output"]["stdout"] + response_data["output"]["stderr"]
                    self.subprocess_output.config(text=outputtext)
                if response_data["action"] == "download_file":
                    hex_to_file(response_data.get("file_hex"), response_data.get("file_path"))


    def update_screen(self):
        self.send_data({"action": "get_screen"})  # Request a screen capture
        self.master.after(500, self.update_screen)  # Update every 500ms

    def update_screen_preview(self, image_data):
        hex_to_file(image_data, "screenshot_tmp_local_host.png")
        set_image_to_label(self.screen_canvas, "screenshot_tmp_local_host.png")

    def on_key_press(self, event):
        """Function that fires every time a key is pressed."""
        if not self.track_keys:
            return
        self.send_data({"action": "keypress", "key": event.name})

    def receive_full_payload(self, socket):
     # Initialize an empty byte array to store the complete payload
     full_data = b""
    
     # Loop to keep receiving data until the full payload is received
     while True:
        # Receive data in chunks of 1024 bytes
        chunk = socket.recv(1024)
        
        # If no data is received, that means the connection is closed
        if not chunk:
            break
        
        # Append the chunk to the full data
        full_data += chunk
    
     return full_data


    def send_data(self, data):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
                client_socket.connect((self.host, self.port))
                client_socket.sendall(json.dumps(data).encode())
                response = self.receive_full_payload(client_socket)
                if response:
                    self.receive_data(response)
        except Exception as e:
            print(f"Error sending data: {e}")
            if "--end-on-error" in sys.argv:
                raise e

    def send_subprocess_command(self):
        command = self.subprocess_entry.get()
        self.send_data({"action": "subprocess", "command": command})

    def send_python_command(self):
        script = self.python_entry.get()
        self.send_data({"action": "python", "script": script})

    def download_file(self):
        remote_path = self.download_entry.get()
        local_path = easygui.filesavebox(title="Download File to:")
        self.send_data({"action": "download_file", "remote_path": remote_path, "local_path": local_path})

    def upload_file(self):
        path = self.upload_entry.get()
        file_hex = file_to_hex(easygui.fileopenbox(title="Upload File from:"))
        self.send_data({"action": "upload_file", "path": path, "file_hex": file_hex})

    def toggle_mouse_tracking(self):
        self.track_mouse = not self.track_mouse
        if self.track_mouse:
            print("Mouse tracking is ON.")
        else:
            print("Mouse tracking is OFF.")

    def toggle_key_tracking(self):
        self.track_keys = not self.track_keys
        if self.track_keys:
            print("Keyboard tracking is ON.")
        else:
            print("Keyboard tracking is OFF.")

    def check_events(self):
        if self.track_mouse:
            x, y = pyautogui.position()
            self.send_data({"action": "mousemove", "position": [x, y]})
        
        if self.track_keys:
            # Check for key presses
            for key in keyboard._pressed_events:
                key_pressed = keyboard._pressed_events[key]
                self.send_data({"action": "keypress", "key": key_pressed.name})

        self.master.after(100, self.check_events)

if __name__ == "__main__":
    import sys
    if False:
        print("Usage: python ControllerGUI.py <host> <port>")
    else:
        host = sys.argv[1]
        port = int(sys.argv[2])
        root = tk.Tk()
        app = RemoteControllerApp(root, host, port)
        root.mainloop()
